// بيانات البنوك الأساسية (مثال)
const bankData = {
  "البنك الأهلي السعودي": {
    address: "ص.ب. 3555 جدة 21481",
    email: "tradej-lg@alahli.com",
    swift: "NCBKSARI"
  },
  "بنك الرياض": {
    address: "ص.ب. 22622 الرياض 11416",
    email: "riyad.services@riyadbank.com",
    swift: "RIBLSARI"
  },
  "مصرف الراجحي": {
    address: "ص.ب. 28 الرياض 11411",
    email: "alrajhi.services@alrajhibank.com.sa",
    swift: "RJHISARI"
  }
};