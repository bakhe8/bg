/* تحميل قائمة البنوك وتعبئة محتوى الخطاب */
const bankSelect = document.getElementById("bankSelect");
const letterContent = document.getElementById("letterContent");
const bankNameInline = document.getElementById("bankNameInline");
const bankAddressInline = document.getElementById("bankAddressInline");
const bankEmailInline = document.getElementById("bankEmailInline");
const printBtn = document.getElementById("printBtn");

function updateLetter(bankName){
  const info = bankData[bankName];
  bankNameInline.textContent = bankName || "—";
  bankAddressInline.textContent = info?.address || "—";
  bankEmailInline.textContent = info?.email || "—";
}

function loadBanks() {
  bankSelect.innerHTML = "";
  Object.keys(window.bankData || {}).forEach(name => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    bankSelect.appendChild(option);
  });
  if (bankSelect.options.length > 0) {
    bankSelect.value = bankSelect.options[0].value;
    updateLetter(bankSelect.value);
  }
}

bankSelect?.addEventListener("change", () => {
  updateLetter(bankSelect.value);
});

printBtn?.addEventListener("click", () => window.print());

// بداية
loadBanks();