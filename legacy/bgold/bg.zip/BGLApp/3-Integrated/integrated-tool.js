let __importedBanks = null;

document.getElementById('convertBtn').addEventListener('click', () => {
  const file = document.getElementById('excelFile').files[0];
  const output = document.getElementById('jsonOutput');
  const importBtn = document.getElementById('importBtn');
  if (!file) return alert('📂 يرجى اختيار ملف Excel أولاً');

  const reader = new FileReader();
  reader.onload = (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const firstSheet = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheet];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    const banks = {};
    rows.forEach(row => {
      const name = row["Name"] || row["Bank Name"] || row["البنك"];
      if (!name) return;
      banks[name] = {
        address: row["Address"] || row["العنوان"] || "",
        email: row["Email"] || row["البريد الإلكتروني"] || "",
        swift: row["SwiftCode"] || row["رمز السويفت"] || ""
      };
    });

    __importedBanks = banks;
    const jsonStr = JSON.stringify(banks, null, 2);
    output.textContent = jsonStr;
    importBtn.style.display = "inline-block";
  };

  reader.readAsArrayBuffer(file);
});

document.getElementById('importBtn').addEventListener('click', () => {
  if (!__importedBanks) return alert('لا توجد بيانات مستوردة بعد.');
  // استبدال bankData في الذاكرة
  window.bankData = __importedBanks;
  // إعادة تعبئة القائمة
  const bankSelect = document.getElementById("bankSelect");
  bankSelect.innerHTML = "";
  Object.keys(bankData).forEach(name => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    bankSelect.appendChild(option);
  });
  if (bankSelect.options.length > 0) {
    bankSelect.value = bankSelect.options[0].value;
    const evt = new Event("change");
    bankSelect.dispatchEvent(evt);
  }
  alert("✅ تم استيراد بيانات البنوك من ملف Excel بنجاح!");
});