document.getElementById('convertBtn').addEventListener('click', () => {
  const file = document.getElementById('excelFile').files[0];
  const output = document.getElementById('jsonOutput');
  if (!file) return alert('📂 يرجى اختيار ملف Excel أولاً');

  const reader = new FileReader();
  reader.onload = (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const firstSheet = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheet];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    // تحويل إلى شكل bankData
    const banks = {};
    rows.forEach(row => {
      const name = row["Name"] || row["Bank Name"] || row["البنك"];
      if (!name) return;
      banks[name] = {
        address: row["Address"] || row["العنوان"] || "",
        email: row["Email"] || row["البريد الإلكتروني"] || "",
        swift: row["SwiftCode"] || row["رمز السويفت"] || ""
      };
    });

    const jsonStr = JSON.stringify(banks, null, 2);
    output.textContent = jsonStr;

    // إنشاء رابط تحميل JSON
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'bank-data.json';
    a.textContent = '⬇️ تحميل bank-data.json';
    output.appendChild(document.createElement('br'));
    output.appendChild(a);
  };

  reader.readAsArrayBuffer(file);
});